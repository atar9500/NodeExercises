const i = 2;

console.log('hello', i);
